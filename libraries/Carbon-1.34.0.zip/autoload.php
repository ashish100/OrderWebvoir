<?php

/**
 * @version 1.34.0
 */

require __DIR__.'/vendor/autoload.php';
